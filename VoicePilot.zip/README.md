# VoicePilot — Voice-Controlled PC Assistant

## About the Project
VoicePilot is a Python-based desktop assistant that allows users to control common computer functions using voice commands.

## Features
- Open Notepad, Calculator, Paint, and the default web browser.
- Search Google and YouTube.
- Control browser tabs, navigation, and scrolling.
- Increase, decrease, mute, and unmute system volume.
- Take screenshots using voice commands.
- Type text using voice commands.
- Use continuous voice typing.

## Technologies Used
- Python 3.11
- SpeechRecognition
- PyAudio
- pyttsx3
- PyAutoGUI
- Pycaw
- comtypes

## How to Run
1. Install Python 3.11.
2. Open a terminal in the project folder.
3. (Recommended) Create and activate a virtual environment.
4. Install dependencies with `pip install -r requirements.txt`.
5. Run `python main.py`.

## Notes
- Google speech recognition requires an internet connection.
- Voice typing sends recognized text to whichever window is currently focused.
- The project is designed for Windows because it uses Windows application launching and system-volume controls.
- Review and test all commands on your own computer before presenting.

## Future Improvements
- Graphical user interface.
- Offline speech recognition.
- Better error handling and more robust command matching.

## Project Goal
To make everyday computer operations easier and more accessible through voice interaction.
