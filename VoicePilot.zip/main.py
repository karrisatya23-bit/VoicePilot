import speech_recognition as sr
import pyttsx3
import pyautogui
import webbrowser
import os
import datetime
from urllib.parse import quote_plus
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from comtypes import CLSCTX_ALL

engine = pyttsx3.init()
recognizer = sr.Recognizer()
typing_mode = False


def speak(text):
    print("VoicePilot:", text)
    engine.say(text)
    engine.runAndWait()


def get_volume():
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(
        IAudioEndpointVolume._iid_, CLSCTX_ALL, None
    )
    return interface.QueryInterface(IAudioEndpointVolume)


def handle_command(command):
    global typing_mode
    command = command.lower().strip()

    if not command:
        return True

    if command == "stop listening":
        speak("Goodbye!")
        return False

    if command == "start voice typing":
        typing_mode = True
        speak("Voice typing started. Say stop typing to finish.")
        return True

    if command == "stop typing":
        typing_mode = False
        speak("Voice typing stopped.")
        return True

    if typing_mode:
        pyautogui.write(command + " ", interval=0.03)
        return True

    if "open notepad" in command:
        os.system("start notepad")
        speak("Opening Notepad")

    elif "open calculator" in command:
        os.system("start calc")
        speak("Opening Calculator")

    elif "open paint" in command:
        os.system("start mspaint")
        speak("Opening Paint")

    elif "open browser" in command or "open chrome" in command:
        webbrowser.open("https://www.google.com")
        speak("Opening your default browser")

    elif command.startswith("search youtube for "):
        query = command.replace("search youtube for ", "", 1)
        webbrowser.open(
            "https://www.youtube.com/results?search_query=" + quote_plus(query)
        )
        speak("Searching YouTube")

    elif command.startswith("search google for "):
        query = command.replace("search google for ", "", 1)
        webbrowser.open(
            "https://www.google.com/search?q=" + quote_plus(query)
        )
        speak("Searching Google")

    elif "new tab" in command:
        pyautogui.hotkey("ctrl", "t")
        speak("New tab opened")

    elif "close tab" in command:
        pyautogui.hotkey("ctrl", "w")
        speak("Tab closed")

    elif "scroll down" in command:
        pyautogui.scroll(-5)

    elif "scroll up" in command:
        pyautogui.scroll(5)

    elif "go back" in command:
        pyautogui.hotkey("alt", "left")

    elif "go forward" in command:
        pyautogui.hotkey("alt", "right")

    elif "refresh" in command:
        pyautogui.press("f5")

    elif "volume up" in command:
        volume = get_volume()
        current = volume.GetMasterVolumeLevelScalar()
        volume.SetMasterVolumeLevelScalar(min(1.0, current + 0.1), None)
        speak("Volume increased")

    elif "volume down" in command:
        volume = get_volume()
        current = volume.GetMasterVolumeLevelScalar()
        volume.SetMasterVolumeLevelScalar(max(0.0, current - 0.1), None)
        speak("Volume decreased")

    elif command == "mute" or "mute volume" in command:
        volume = get_volume()
        volume.SetMute(1, None)
        speak("Volume muted")

    elif command == "unmute" or "unmute volume" in command:
        volume = get_volume()
        volume.SetMute(0, None)
        speak("Volume unmuted")

    elif "screenshot" in command:
        pyautogui.screenshot().save("screenshot.png")
        speak("Screenshot saved as screenshot.png")

    elif command.startswith("type "):
        text_to_type = command[5:]
        pyautogui.write(text_to_type, interval=0.03)
        speak("Text typed")

    elif "what time" in command:
        now = datetime.datetime.now().strftime("%I:%M %p")
        speak("The time is " + now)

    else:
        speak("Sorry, I did not understand that command.")

    return True


def main():
    speak("Welcome to VoicePilot. I am ready for your commands.")

    with sr.Microphone() as source:
        print("Calibrating microphone... Please stay quiet.")
        recognizer.adjust_for_ambient_noise(source, duration=2)
        recognizer.energy_threshold = 300
        recognizer.dynamic_energy_threshold = True
        recognizer.pause_threshold = 0.8
        speak("VoicePilot is ready. Start speaking.")

        running = True
        while running:
            try:
                print("\nListening...")
                audio = recognizer.listen(source, timeout=5)
                command = recognizer.recognize_google(audio)
                print("You said:", command)
                running = handle_command(command)

            except sr.WaitTimeoutError:
                continue
            except sr.UnknownValueError:
                print("Could not understand. Please try again.")
            except sr.RequestError:
                speak("Speech recognition requires an internet connection.")
            except Exception as error:
                print("Error:", error)


if __name__ == "__main__":
    main()
